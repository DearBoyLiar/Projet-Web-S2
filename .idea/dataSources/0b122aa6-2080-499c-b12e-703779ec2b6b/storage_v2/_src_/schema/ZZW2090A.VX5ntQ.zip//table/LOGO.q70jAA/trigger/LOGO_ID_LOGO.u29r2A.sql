CREATE TRIGGER LOGO_ID_LOGO
  BEFORE INSERT
  ON LOGO
  FOR EACH ROW
  WHEN (NEW.id_logo IS NULL)
  BEGIN
    select seq_logo_id_logo.NEXTVAL INTO :NEW.id_logo from DUAL;
  END;
/

