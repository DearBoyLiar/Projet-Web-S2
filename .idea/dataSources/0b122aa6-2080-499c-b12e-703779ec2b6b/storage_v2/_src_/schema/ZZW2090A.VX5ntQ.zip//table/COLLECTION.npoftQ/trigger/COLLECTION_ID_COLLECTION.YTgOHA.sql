CREATE TRIGGER COLLECTION_ID_COLLECTION
  BEFORE INSERT
  ON COLLECTION
  FOR EACH ROW
  WHEN (NEW.id_collection IS NULL)
  BEGIN
    select seq_collection_id_collection.NEXTVAL INTO :NEW.id_collection from DUAL;
  END;
/

