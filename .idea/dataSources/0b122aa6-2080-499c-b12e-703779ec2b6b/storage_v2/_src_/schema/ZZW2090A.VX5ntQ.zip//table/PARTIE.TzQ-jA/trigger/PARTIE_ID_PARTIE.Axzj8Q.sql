CREATE TRIGGER PARTIE_ID_PARTIE
  BEFORE INSERT
  ON PARTIE
  FOR EACH ROW
  WHEN (NEW.id_partie IS NULL)
  BEGIN
    select seq_partie_id_partie.NEXTVAL INTO :NEW.id_partie from DUAL;
  END;
/

