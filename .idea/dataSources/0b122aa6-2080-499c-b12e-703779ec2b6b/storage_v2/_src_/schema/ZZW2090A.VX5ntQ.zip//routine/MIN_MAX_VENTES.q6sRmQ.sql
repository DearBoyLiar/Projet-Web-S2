CREATE procedure min_max_ventes(vdateC Commande.datec%TYPE, vidPmin out Produit.idP%TYPE, vidPmax out Produit.idP%TYPE) as

  begin

    -- l'utilisation du rownum est nécessaire ici pour ne revnoyer qu'un seul produit (plusieurs produits peuvent correspondre au max).
    select idP  into vidPmin from (
      select idP
      from Commande, Detail
      where commande.idCo = Detail.idCo
            and dateC=vdateC
      group by idP
      having sum(nombre)=(select max(sum(nombre))
                          from Commande, detail
                          where commande.idCo = Detail.idCo
                                and dateC=vdateC
                          group by idP))
    where rownum=1;


    select idP into vidPmax from (
      select idP
      from Commande, Detail
      where commande.idCo = Detail.idCo
            and dateC=vdateC
      group by idP
      having sum(nombre)=(select min(sum(nombre))
                          from commande, detail
                          where commande.idCo = Detail.idCo
                                and dateC=vdateC
                          group by idP))
    where rownum=1;


  end;
/

