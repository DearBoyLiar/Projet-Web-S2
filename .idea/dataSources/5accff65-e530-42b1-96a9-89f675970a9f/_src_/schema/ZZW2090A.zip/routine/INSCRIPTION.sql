CREATE PROCEDURE inscription(ppseudo UTILISATEUR.pseudo%TYPE,ppassword UTILISATEUR) IS 
  BEGIN 
    INSERT INTO UTILISATEUR(PSEUDO,MOT_DE_PASSE) VALUES (ppseudo,ppassword):
  EXCEPTION 
    WHEN DUP_VAL_ON_INDEX THEN 
      raise_application_error(-20001,'Ce compte existe déjà');
  END;
/
